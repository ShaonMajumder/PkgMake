# PkgMake
A helper for making pacakages without writing the configuration again and again.
Which terminates repeatative tasks.